﻿using DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace BAL
{
   public interface IStudent
    {
        Student Login(Student data);
        Student SignUp(Student data);

    }
}
