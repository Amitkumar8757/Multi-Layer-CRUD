﻿using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BAL
{
    public class StudentServices : IStudent
    {
        private readonly StudentDbContext db;
        public StudentServices(StudentDbContext _db)
        {
            db = _db;
        }

        public Student SignUp(Student data)
        {
            var record = db.GetStudents.Add(data);
            db.SaveChanges();
            return data;
        }

        public Student Login(Student data)
        {
                var result = db.GetStudents.SingleOrDefault(e => e.Email == data.Email && e.Password == data.Password);
                if (result != null)
                {
                    return data;
                }
            
            return null;
        }

    }
}
