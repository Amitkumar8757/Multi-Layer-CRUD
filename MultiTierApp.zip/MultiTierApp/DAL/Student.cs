﻿using System;
using System.ComponentModel.DataAnnotations;

namespace DAL
{
    public class Student
    {
        public int Id { get; set; }
        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Enter First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Enter Last Name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Enter Email Address")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Enter valid Email")]
        public string Email { get; set; }
        [Required(ErrorMessage = "Enter Mobile Number")]
        [DataType(DataType.PhoneNumber, ErrorMessage = "Enter valid mobile number")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$",
                  ErrorMessage = "Entered phone format is not valid.")]
        public string Mobile { get; set; }
        [Required(ErrorMessage = "Gender is required")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Address is required")]
        public string Address { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string  ConfirmPassword { get; set; }
    }
}
