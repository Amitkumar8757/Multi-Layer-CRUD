﻿using BAL;
using DAL;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiTierApp.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudent student;
        public StudentController(IStudent _student)
        {
            student = _student;
        }


          public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(Student data)
        {


            var record = student.SignUp(data);
            return RedirectToAction("Login");
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Student data)
        {
          
                var result = student.Login(data);
            if (result != null)
            {

                return RedirectToAction("DASHBOARD");
            }
            else
            {
                ViewBag.InvalidUser = "Invalid username and password!";
            }
            return View();
        }


      
        public IActionResult DASHBOARD()
        {
            return View();
        }
    }
}
